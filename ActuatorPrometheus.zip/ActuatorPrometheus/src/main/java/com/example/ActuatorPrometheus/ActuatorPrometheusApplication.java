package com.example.ActuatorPrometheus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActuatorPrometheusApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActuatorPrometheusApplication.class, args);
	}

}
