package com.example.ActuatorPrometheus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActuatorPrometheusApplicationTests {

	@Test
	void contextLoads() {
	}

}
